/**
 *  Copyright (c) Electronics and Telecommunications Research Institute. All rights reserved.
 *  See License.txt in the project root for license information.
 */

module.exports.ns = ['service', 'doc', 'error', 'system'] // except: joi
